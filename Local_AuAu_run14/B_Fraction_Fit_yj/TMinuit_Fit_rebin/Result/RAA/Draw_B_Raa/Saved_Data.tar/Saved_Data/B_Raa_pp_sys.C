{
//========= Macro generated from object: Graph_from_Fb_to_Raa_e_pp_sys/
//========= by ROOT version6.06/08
   
   Double_t Graph_from_Fb_to_Raa_e_pp_sys_fx1005[4] = {
   3,
   4,
   5,
   7};
   Double_t Graph_from_Fb_to_Raa_e_pp_sys_fy1005[4] = {
   1.10123,
   0.808191,
   0.721504,
   0.782421};
   Double_t Graph_from_Fb_to_Raa_e_pp_sys_fex1005[4] = {
   0,
   0,
   0,
   0};
   Double_t Graph_from_Fb_to_Raa_e_pp_sys_fey1005[4] = {
   0.212304,
   0.252693,
   0.34613,
   0.271845};
   gre = new TGraphErrors(4,Graph_from_Fb_to_Raa_e_pp_sys_fx1005,Graph_from_Fb_to_Raa_e_pp_sys_fy1005,Graph_from_Fb_to_Raa_e_pp_sys_fex1005,Graph_from_Fb_to_Raa_e_pp_sys_fey1005);
   gre->SetName("Graph_from_Fb_to_Raa_e_pp_sys");
   gre->SetTitle("");
   gre->Draw("");
}
