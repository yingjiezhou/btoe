{
//========= Macro generated from object: Graph_from_Fc_to_e_Raa_pp_sys/
//========= by ROOT version6.06/08
   
   Double_t Graph_from_Fc_to_e_Raa_pp_sys_fx1006[4] = {
   3,
   4,
   5,
   7};
   Double_t Graph_from_Fc_to_e_Raa_pp_sys_fy1006[4] = {
   0.492848,
   0.245403,
   0.321857,
   0.332957};
   Double_t Graph_from_Fc_to_e_Raa_pp_sys_fex1006[4] = {
   0,
   0,
   0,
   0};
   Double_t Graph_from_Fc_to_e_Raa_pp_sys_fey1006[4] = {
   0.0468279,
   0.0188295,
   0.0496965,
   0.0385175};
   gre = new TGraphErrors(4,Graph_from_Fc_to_e_Raa_pp_sys_fx1006,Graph_from_Fc_to_e_Raa_pp_sys_fy1006,Graph_from_Fc_to_e_Raa_pp_sys_fex1006,Graph_from_Fc_to_e_Raa_pp_sys_fey1006);
   gre->SetName("Graph_from_Fc_to_e_Raa_pp_sys");
   gre->SetTitle("");
   gre->SetLineColor(2);
   gre->Draw("");
}
