{
//========= Macro generated from object: Graph_from_Npe_Raa_all_sys/
//========= by ROOT version6.06/08
   
   Double_t Graph_from_Npe_Raa_all_sys_fx1008[4] = {
   3,
   4,
   5,
   6.75};
   Double_t Graph_from_Npe_Raa_all_sys_fy1008[4] = {
   0.685687,
   0.480987,
   0.515541,
   0.567754};
   Double_t Graph_from_Npe_Raa_all_sys_fex1008[4] = {
   0.06,
   0.06,
   0.06,
   0.06};
   Double_t Graph_from_Npe_Raa_all_sys_fey1008[4] = {
   0.0866199,
   0.0351662,
   0.0431478,
   0.0880557};
   gre = new TGraphErrors(4,Graph_from_Npe_Raa_all_sys_fx1008,Graph_from_Npe_Raa_all_sys_fy1008,Graph_from_Npe_Raa_all_sys_fex1008,Graph_from_Npe_Raa_all_sys_fey1008);
   gre->SetName("Graph_from_Npe_Raa_all_sys");
   gre->SetTitle("");
   gre->SetFillColor(41);
   gre->SetLineColor(41);
   
   TH1F *Graph_Graph_from_Npe_Raa_all_sys1008 = new TH1F("Graph_Graph_from_Npe_Raa_all_sys1008","",100,2.553,7.197);
   Graph_Graph_from_Npe_Raa_all_sys1008->SetMinimum(0.413173);
   Graph_Graph_from_Npe_Raa_all_sys1008->SetMaximum(0.804956);
   Graph_Graph_from_Npe_Raa_all_sys1008->SetDirectory(0);
   Graph_Graph_from_Npe_Raa_all_sys1008->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph_from_Npe_Raa_all_sys1008->SetLineColor(ci);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetXaxis()->SetLabelFont(42);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetXaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetXaxis()->SetTitleSize(0.06);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetXaxis()->SetTitleFont(42);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetYaxis()->SetLabelFont(42);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetYaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetYaxis()->SetTitleSize(0.06);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetYaxis()->SetTitleFont(42);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetZaxis()->SetLabelFont(42);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetZaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetZaxis()->SetTitleSize(0.035);
   Graph_Graph_from_Npe_Raa_all_sys1008->GetZaxis()->SetTitleFont(42);
   gre->SetHistogram(Graph_Graph_from_Npe_Raa_all_sys1008);
   
   gre->Draw("");
}
