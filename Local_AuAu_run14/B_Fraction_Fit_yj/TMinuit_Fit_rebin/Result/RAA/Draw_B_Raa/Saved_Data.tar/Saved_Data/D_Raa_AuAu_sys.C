{
//========= Macro generated from object: Graph_from_Fc_to_e_Raa_sys/
//========= by ROOT version6.06/08
   
   Double_t Graph_from_Fc_to_e_Raa_sys_fx1007[4] = {
   3,
   4,
   5,
   7};
   Double_t Graph_from_Fc_to_e_Raa_sys_fy1007[4] = {
   0.492848,
   0.245403,
   0.321857,
   0.332957};
   Double_t Graph_from_Fc_to_e_Raa_sys_fex1007[4] = {
   0.06,
   0.06,
   0.06,
   0.06};
   Double_t Graph_from_Fc_to_e_Raa_sys_fey1007[4] = {
   0.0787814,
   0.0275335,
   0.0287026,
   0.0636893};
   gre = new TGraphErrors(4,Graph_from_Fc_to_e_Raa_sys_fx1007,Graph_from_Fc_to_e_Raa_sys_fy1007,Graph_from_Fc_to_e_Raa_sys_fex1007,Graph_from_Fc_to_e_Raa_sys_fey1007);
   gre->SetName("Graph_from_Fc_to_e_Raa_sys");
   gre->SetTitle("");
   gre->SetFillColor(17);
   gre->SetLineColor(17);
   
   TH1F *Graph_Graph_from_Fc_to_e_Raa_sys1007 = new TH1F("Graph_Graph_from_Fc_to_e_Raa_sys1007","",100,2.528,7.472);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->SetMinimum(0.182493);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->SetMaximum(0.607005);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->SetDirectory(0);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph_from_Fc_to_e_Raa_sys1007->SetLineColor(ci);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetXaxis()->SetLabelFont(42);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetXaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetXaxis()->SetTitleSize(0.06);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetXaxis()->SetTitleFont(42);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetYaxis()->SetLabelFont(42);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetYaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetYaxis()->SetTitleSize(0.06);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetYaxis()->SetTitleFont(42);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetZaxis()->SetLabelFont(42);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetZaxis()->SetLabelSize(0.035);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetZaxis()->SetTitleSize(0.035);
   Graph_Graph_from_Fc_to_e_Raa_sys1007->GetZaxis()->SetTitleFont(42);
   gre->SetHistogram(Graph_Graph_from_Fc_to_e_Raa_sys1007);
   
   gre->Draw("");
}
