{
//========= Macro generated from object: Fc_to_e_Raa_sts/
//========= by ROOT version6.06/08
   Double_t xAxis3[5] = {2.5, 3.5, 4.5, 5.5, 8.5}; 
   
   TH1F *Fc_to_e_Raa_sts__3 = new TH1F("Fc_to_e_Raa_sts__3","",4, xAxis3);
   Fc_to_e_Raa_sts__3->SetBinContent(1,0.492848);
   Fc_to_e_Raa_sts__3->SetBinContent(2,0.245403);
   Fc_to_e_Raa_sts__3->SetBinContent(3,0.321857);
   Fc_to_e_Raa_sts__3->SetBinContent(4,0.332957);
   Fc_to_e_Raa_sts__3->SetBinError(1,0.0635228);
   Fc_to_e_Raa_sts__3->SetBinError(2,0.0570656);
   Fc_to_e_Raa_sts__3->SetBinError(3,0.115263);
   Fc_to_e_Raa_sts__3->SetBinError(4,0.248364);
   Fc_to_e_Raa_sts__3->SetEntries(23.5909);
   Fc_to_e_Raa_sts__3->SetStats(0);
   Fc_to_e_Raa_sts__3->SetLineColor(2);
   Fc_to_e_Raa_sts__3->SetMarkerColor(2);
   Fc_to_e_Raa_sts__3->SetMarkerStyle(20);
   Fc_to_e_Raa_sts__3->SetMarkerSize(2.2);
   Fc_to_e_Raa_sts__3->GetXaxis()->SetLabelFont(42);
   Fc_to_e_Raa_sts__3->GetXaxis()->SetLabelSize(0.035);
   Fc_to_e_Raa_sts__3->GetXaxis()->SetTitleSize(0.06);
   Fc_to_e_Raa_sts__3->GetXaxis()->SetTitleFont(42);
   Fc_to_e_Raa_sts__3->GetYaxis()->SetLabelFont(42);
   Fc_to_e_Raa_sts__3->GetYaxis()->SetLabelSize(0.035);
   Fc_to_e_Raa_sts__3->GetYaxis()->SetTitleSize(0.06);
   Fc_to_e_Raa_sts__3->GetYaxis()->SetTitleFont(42);
   Fc_to_e_Raa_sts__3->GetZaxis()->SetLabelFont(42);
   Fc_to_e_Raa_sts__3->GetZaxis()->SetLabelSize(0.035);
   Fc_to_e_Raa_sts__3->GetZaxis()->SetTitleSize(0.035);
   Fc_to_e_Raa_sts__3->GetZaxis()->SetTitleFont(42);
   Fc_to_e_Raa_sts__3->Draw("");
}
