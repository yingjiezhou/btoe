{
//========= Macro generated from object: Fb_to_e_sts/
//========= by ROOT version6.06/08
   Double_t xAxis1[5] = {2.5, 3.5, 4.5, 5.5, 8.5}; 
   
   TH1F *Fb_to_e_sts__1 = new TH1F("Fb_to_e_sts__1","",4, xAxis1);
   Fb_to_e_sts__1->SetBinContent(1,2.23442);
   Fb_to_e_sts__1->SetBinContent(2,3.29332);
   Fb_to_e_sts__1->SetBinContent(3,2.24169);
   Fb_to_e_sts__1->SetBinContent(4,2.34991);
   Fb_to_e_sts__1->SetBinError(1,0.512299);
   Fb_to_e_sts__1->SetBinError(2,0.956996);
   Fb_to_e_sts__1->SetBinError(3,0.965603);
   Fb_to_e_sts__1->SetBinError(4,1.89747);
   Fb_to_e_sts__1->SetEntries(17.9303);
   Fb_to_e_sts__1->SetStats(0);
   Fb_to_e_sts__1->SetLineColor(4);
   Fb_to_e_sts__1->SetMarkerColor(4);
   Fb_to_e_sts__1->SetMarkerStyle(20);
   Fb_to_e_sts__1->SetMarkerSize(2);
   Fb_to_e_sts__1->GetXaxis()->SetLabelFont(42);
   Fb_to_e_sts__1->GetXaxis()->SetLabelSize(0.035);
   Fb_to_e_sts__1->GetXaxis()->SetTitleSize(0.06);
   Fb_to_e_sts__1->GetXaxis()->SetTitleFont(42);
   Fb_to_e_sts__1->GetYaxis()->SetLabelFont(42);
   Fb_to_e_sts__1->GetYaxis()->SetLabelSize(0.035);
   Fb_to_e_sts__1->GetYaxis()->SetTitleSize(0.06);
   Fb_to_e_sts__1->GetYaxis()->SetTitleFont(42);
   Fb_to_e_sts__1->GetZaxis()->SetLabelFont(42);
   Fb_to_e_sts__1->GetZaxis()->SetLabelSize(0.035);
   Fb_to_e_sts__1->GetZaxis()->SetTitleSize(0.035);
   Fb_to_e_sts__1->GetZaxis()->SetTitleFont(42);
   Fb_to_e_sts__1->Draw("");
}
