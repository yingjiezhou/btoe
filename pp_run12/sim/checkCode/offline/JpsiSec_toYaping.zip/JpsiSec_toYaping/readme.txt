#only the cross section code, let Yaping help me to check


################
# generate e and jpsi cross section using seeting from web: https://www.star.bnl.gov/protected/heavy/ullrich/pythia8/
In RCF:

generation code:
/star/u/yjzhou19/pp_npe/sim/crossSectionJpsi

star HF tune from website: hard qcd bc
/star/u/yjzhou19/pp_npe/sim/crossSectionJpsi/star_hf_tune_v1.1.cmnd
output directory: /star/u/yjzhou19/pp_npe/sim/minBiasTemplates/crossSectionJpsi_HQbc
output filelist: /star/u/yjzhou19/pp_npe/sim/minBiasTemplates/readPythiaOutputs/crossSectionJpsi_HQbc.list

star HF tune: "pythia old tune"
/star/u/yjzhou19/pp_npe/sim/crossSectionJpsi/MB/star_hf_tune_v1.1.cmnd
output directory: /star/u/yjzhou19/pp_npe/sim/minBiasTemplates/crossSectionJpsi_MB
output filelist: /star/u/yjzhou19/pp_npe/sim/minBiasTemplates/readPythiaOutputs/crossSectionJpsi_MB.list


#read tree, save e, jpsi cross section
In RCF:
/star/u/yjzhou19/pp_npe/sim/minBiasTemplates/readPythiaOutputs/readTreeSecJpsi.C


#calculate cross section, make a comparison
In local:
plotDirectJpsi_comp.C
